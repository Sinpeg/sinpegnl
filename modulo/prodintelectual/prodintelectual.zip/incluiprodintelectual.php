<?php
//require_once('../../includes/classes/sessao.php');
//session_start();
$sessao = $_SESSION["sessao"];
$aplicacoes = $sessao->getAplicacoes();
if (!$aplicacoes[4]) {
    header("Location:index.php");
} 
//$nomeunidade = $sessao->getNomeUnidade();
//$codunidade = $sessao->getCodUnidade();
//$responsavel = $sessao->getResponsavel();
$anobase = $sessao->getAnoBase();
//require_once('../../includes/dao/PDOConnectionFactory.php');
require_once('dao/prodintelectualDAO.php');
require_once('classes/prodintelectual.php');
require_once('dao/tipoprodintelectualDAO.php');
require_once('classes/tipoprodintelectual.php');
require_once('./classes/curso.php');
$codcurso = $_GET["codcurso"];
$nomecurso = $_GET["nomecurso"];
$daopi = new prodintelectualDAO();
if ($codcurso != "" && $nomecurso != "" &&
        is_numeric($codcurso) && is_string($nomecurso)) {
    $tiposie = array();
    $cont = 0;
    $daotpi = new TipoprodintelectualDAO();
    $validade=2014;
    if ($anobase<=2013)
    	$validade=2013;
    //$rows_pi = $daopi->tiponaoinserido($codcurso, $anobase);
    $rows_pi = $daotpi->Lista($validade);
    foreach ($rows_pi as $row) {
        $cont++;
        $tipospi[$cont] = new Tipoprodintelectual();
        $tipospi[$cont]->setCodigo($row['Codigo']);
        $tipospi[$cont]->setNome($row['Nome']);
    }
    $tamanho = count($tipospi);
   
$daopi->fechar();
//if ($tamanho == 0) {
   //Utils::redirect('prodintelectual', 'consultaprodintelectual', array('codcurso' => $codcurso, 'nomecurso' => $nomecurso));

//}
}
//ob_end_flush();
?>       
 <script language="javascript">
    function Soma() {
        var multi_prodi = document.pi.elements["prodi[]"];
        var soma = 0;
        for (var i = 0; i < multi_prodi.length; i++)
        {
            if (!isNaN(parseInt(multi_prodi[i].value, 10))) {
                soma += parseInt(multi_prodi[i].value, 10);
            }
        }
        document.getElementById('totalgeral').innerHTML = soma;
    }
    function SomenteNumero(e) {
        var tecla = (window.event) ? event.keyCode : e.which;
        //0 a 9 em ASCII
        if ((tecla > 47 && tecla < 58)) {
            document.getElementById('msg').innerHTML = " ";
            return true;
        }
        else {
            if (tecla == 8 || tecla == 0) {
                document.getElementById('msg').innerHTML = " ";
                return true;//Aceita tecla tab
            }
            else {
                document.getElementById('msg').innerHTML = "Todos os campos devem conter apenas números.";
                return false;
            }
        }
    }
    function direciona(botao) {
        switch (botao) {
            case 1:
                if (valida()) {
                    document.getElementById('pi').action = "?modulo=prodintelectual&acao=opprodintelectual";
                    document.getElementById('pi').submit();
                }
                break;
            case 2:
                document.getElementById('pi').action = "?modulo=prodintelectual&acao=consultapi";
                document.getElementById('pi').submit();
                break;
            case 3:
                document.getElementById('pi').action = "?modulo=prodintelectual&acao=consultaitempi";
                document.getElementById('pi').submit();
                break;
        }

    }
    function valida() {
        var multi_prodi = document.pi.elements["prodi[]"];
        var soma = 0;
        var passou = false;
        for (var i = 0; i < multi_prodi.length; i++) {
            if (isNaN(parseInt(multi_prodi[i].value, 10))) {
                document.getElementById('msg').innerHTML = "Todos os campos são obrigatórios. Não deixe campos em branco, digite 0.";
                passou = true;
            }
        }
        if (passou) {
            return false;
        }
        else {
            return true;
        }
    }
</script>
<form name="pi" id="pi" method="post">
    <h3>Produção Intelectual</h3>
    Curso:
    <?php echo $nomecurso; ?>
    <br />
    <div class="msg" id="msg"></div>
    <br />

    <table>
        <tr align="center" style="font-style: italic;">
            <td>Itens</td>
            <td>Quantidade</td>
        </tr>
        <?php
        $cont = 0;
        foreach ($tipospi as $t) {
            ?>
            <tr>
                <td><?php print ($t->getNome()); ?></td>
                <td>
                    <input type="text" name="prodi[]" size="7"  maxlength="4"
                           onkeypress='return SomenteNumero(event)' value="" onchange="Soma();"  /></td>
            </tr>
        <?php }//for	 ?>
        <tr>
            <td></td>
            <td>
                <input type="hidden" name="prodi[]" size="7"  maxlength="4"	 value='0'  onchange="Soma();"  />
            </td>
        </tr>
        <tr style="font-style:italic;"><td>Total Geral</td><td><b id='totalgeral'></b></td></tr>
    </table>
    <input name="operacao" type="hidden" value="I" />
    <input type="button" onclick="direciona(1);" value="Gravar" class="btn btn-primary" />
    <input type="button" onclick="direciona(2);" value="Consultar" class="btn btn-primary" />
 <!--     <input type="button" onclick="direciona(3);" value="Incluir novo item" class="btn btn-primary" />-->
    <input	type="hidden" name="codcurso" value="<?php print $codcurso ?>" />
    <input	type="hidden" name="nomecurso" value="<?php print $nomecurso ?>" />

</form>
