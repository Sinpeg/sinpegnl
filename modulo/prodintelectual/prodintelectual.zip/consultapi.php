<?php
$sessao = $_SESSION['sessao'];
$aplicacoes = $sessao->getAplicacoes();
if (!$aplicacoes[4]) {
    header("Location:index.php");
}
//$sessao = $_SESSION["sessao"];
//$nomeunidade = $sessao->getNomeUnidade();
//$codunidade = $sessao->getCodUnidade();
//$responsavel = $sessao->getResponsavel();
$anobase = $sessao->getAnoBase();

//require_once('../../includes/dao/PDOConnectionFactory.php');

require_once('dao/prodintelectualDAO.php');
require_once('classes/prodintelectual.php');

require_once('dao/tipoprodintelectualDAO.php');
require_once('classes/tipoprodintelectual.php');

//require_once('../../includes/classes/curso.php');

$codcurso = $_POST["codcurso"];
$nomecurso = $_POST["nomecurso"];
if ($codcurso != "" && is_numeric($codcurso) && is_string($nomecurso) && $nomecurso != "") {

    $tiposie = array();
    $cont = 0;
    $daotpi = new TipoprodintelectualDAO();
    $daopi = new ProdintelectualDAO();

    $rows_tpi = $daotpi->Lista();
    foreach ($rows_tpi as $row) {
        $cont++;
        $tipospi[$cont] = new Tipoprodintelectual();
        $tipospi[$cont]->setCodigo($row['Codigo']);
        $tipospi[$cont]->setNome($row['Nome']);
    }
    $cont1 = 0;

    $curso = new Curso();
    $curso->setCodcurso($codcurso);
    $curso->setNomecurso($nomecurso);
    $soma = 0;
    $tamanho = count($tipospi);

    $rows_pi = $daopi->buscapiunidade($codcurso, $anobase);

    foreach ($rows_pi as $row) {
        $tipo = $row['Tipo'];
        for ($i = 1; $i <= $tamanho; $i++) {
            if ($tipospi[$i]->getCodigo() == $tipo) {
                $cont1++;
                $tipospi[$i]->criaProdintelectual($row["Codigo"], $curso, $anobase, $row["Quantidade"]);
                $soma +=$row["Quantidade"];
            }
        }
    }
}
$daotpi->fechar();
//ob_end_flush();
?>
<script language="JavaScript">
    function direciona(botao) {
        switch (botao) {
            case 1:
                document.getElementById('pi').action = "?modulo=prodintelectual&acao=altprodintelectual";
                document.getElementById('pi').submit();
                break;
            case 2:
                document.getElementById('pi').action = "?modulo=prodintelectual&acao=consultaitempi";
                document.getElementById('pi').submit();
                break;
        }
    }

</script>
<form name="pi" id="pi" method="get">
    <h3> Produ&ccedil;ao Intelectual </h3> Curso:
    <?php echo $nomecurso; ?>
    <div class="msg" id="msg"></div>
    <br />

    <table>
        <tr align="center" style="font-style: italic;">
            <td width="600px">Itens</td>
            <td width="100px">Quantidade</td>
        </tr>
        <?php foreach ($tipospi as $t) {
            if ($t->getProdintelectual() != NULL) {
                ?>
                <tr>
                    <td><?php print ($t->getNome()); ?></td>
                    <td><?php print $t->getProdintelectual()->getQuantidade(); ?></td>
                </tr>
            <?php }
        }
        ?>
        <tr><td>Total Geral</td><td><b><?php print $soma; ?></b></td></tr>
    </table>
    <input name="operacao" type="hidden" value="A" />
    <input type="button" onclick="direciona(1);" value="Alterar" class="btn btn-primary"/>
    <input type="button" onclick="direciona(2);" value="Incluir novo item" class="btn btn-primary" />
    <input type="hidden" name="codcurso" value="<?php print $codcurso ?>" />
    <input type="hidden" name="nomecurso" value="<?php print $nomecurso ?>" />
</form>
</body>
</html>

