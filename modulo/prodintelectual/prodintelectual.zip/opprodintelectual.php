<?php
//set_include_path(';../../includes');
//require_once('../../includes/classes/sessao.php');
//require_once('../../includes/dao/PDOConnectionFactory.php');
require_once('classes/prodintelectual.php');
require_once('dao/prodintelectualDAO.php');
require_once('classes/tipoprodintelectual.php');
require_once('dao/tipoprodintelectualDAO.php');
//session_start();
$sessao = $_SESSION["sessao"];
$aplicacoes = $sessao->getAplicacoes();
if (!$aplicacoes[4]) {
    header("Location:index.php");
} 
//$nomeUnidade = $sessao->getNomeunidade();
//$codUnidade = $sessao->getCodunidade();
//$responsavel = $sessao->getResponsavel();
$anobase = $sessao->getAnobase();
//require_once('../../includes/classes/curso.php');
$tipoPI = $_POST['prodi'];
$codcurso = $_POST["codcurso"];
$nomecurso = $_POST["nomecurso"];
$operacao = $_POST["operacao"];
$erro = false;

foreach ($tipoPI as $i => $qtde) {
    if (!preg_match('/^[0-9]+$/', $qtde)) {
        $erro = true;
        break;
    }
}
if ($erro) {
    $mensagem = urlencode(" ");
    $cadeia = "location:../saida/erro.php?codigo=1&mensagem=" . $mensagem;
    header($cadeia);
} else {
    $curso = new Curso();
    $curso->setCodcurso($codcurso);
    $cont = 0;
    $i = 0;
    $daopi = new ProdintelectualDAO();
    $daotpi = new TipoprodintelectualDAO();
    if ($operacao == "I") {
        $rows = $daopi->tiponaoinserido($codcurso, $anobase);
        foreach ($rows as $row) {
            $cont++;
            $tPI[$cont] = new Tipoprodintelectual();
            $tPI[$cont]->setCodigo($row["Codigo"]); //código do tipo - tabela tipo de prod int
            if ($operacao == "I") {
                $tPI[$cont]->criaProdintelectual(null, $curso, $anobase, $tipoPI[$i]);
            }
            $i++;
        }
        $daopi->inseretodos($tPI);
    } elseif ($operacao == "A") {
        $rows = $daopi->buscapiunidade($codcurso, $anobase);
        foreach ($rows as $row) {
            $cont++;
            $tPI[$cont] = new Tipoprodintelectual();
            $tPI[$cont]->setCodigo($row["Tipo"]);
            $consulta = $daopi->buscapi($codcurso, $anobase, $row["Tipo"]); //tabela prodintelectual
            foreach ($consulta as $row1) {
                $tPI[$cont]->criaProdintelectual($row1["Codigo"], $curso, $anobase, $tipoPI[$i]);
            }
            $i++;
        }
        $daopi->alteratodos($tPI);
        Flash::addFlash('Dados da Produção Intelectual atualizados com sucesso!');
    }
}

//foreach ($tipoPI as $i => $qtde) {
//    if (!preg_match('/^[1-9][0-9]*$/', $qtde)) {
//        $passou = false;
//        break;
//    }
//}
//if (!$passou) {
//    $mensagem = urlencode(" ");
//    $cadeia = "location:../saida/erro.php?codigo=1&mensagem=" . $mensagem;
//    header($cadeia);
//    exit();
//}
//$curso = new Curso();
//$curso->setCodcurso($codcurso);
//$cont = 0;
//$i = 0;
//$daopi = new ProdintelectualDAO();
//$daotpi = new TipoprodintelectualDAO();
//$passou = false;
//if ($operacao == "I") {
//    $rows = $daopi->tiponaoinserido($codcurso, $anobase);
//    foreach ($rows as $row) {
//        $cont++;
//        $tPI[$cont] = new Tipoprodintelectual();
//        $tPI[$cont]->setCodigo($row["Codigo"]); //código do tipo - tabela tipo de prod int
//        if ($operacao == "I") {
//            $tPI[$cont]->criaProdintelectual(null, $curso, $anobase, $tipoPI[$i]);
//        }
//        $i++;
//    }
//    $daopi->inseretodos($tPI);
//} elseif ($operacao == "A") {
//    $rows = $daopi->buscapiunidade($codcurso, $anobase);
//    foreach ($rows as $row) {
//        $cont++;
//        $tPI[$cont] = new Tipoprodintelectual();
//        $tPI[$cont]->setCodigo($row["Tipo"]);
//        $consulta = $daopi->buscapi($codcurso, $anobase, $row["Tipo"]); //tabela prodintelectual
//        foreach ($consulta as $row1) {
//            $tPI[$cont]->criaProdintelectual($row1["Codigo"], $curso, $anobase, $tipoPI[$i]);
//        }
//        $i++;
//    }
//    $daopi->alteratodos($tPI);
//}
$daopi->fechar();
//$cadeia = "location:consultaprodintelectual.php?codcurso=" . $codcurso . "&nomecurso=" . $nomecurso;
Utils::redirect('prodintelectual', 'consultaprodintelectual', array('codcurso'=>$codcurso, 'nomecurso'=>$nomecurso));
//header($cadeia);
//ob_end_flush();
?>