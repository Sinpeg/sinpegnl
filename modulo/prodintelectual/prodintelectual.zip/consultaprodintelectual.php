<?php
//require_once('../../includes/classes/sessao.php');
$sessao = $_SESSION['sessao'];
$aplicacoes = $sessao->getAplicacoes();
if (!$aplicacoes[4]) {
    header("Location:index.php");
}
//$sessao = $_SESSION["sessao"];
//$nomeunidade = $sessao->getNomeUnidade();
//$codunidade = $sessao->getCodUnidade();
//$responsavel = $sessao->getResponsavel();
$anobase = $sessao->getAnoBase();
//require_once('../../includes/dao/PDOConnectionFactory.php');
require_once('dao/prodintelectualDAO.php');
require_once('classes/prodintelectual.php');
require_once('dao/tipoprodintelectualDAO.php');
require_once('classes/tipoprodintelectual.php');
require_once('./classes/curso.php');
$codcurso = $_GET["codcurso"];
$nomecurso = $_GET["nomecurso"];
if ($codcurso != "" && is_numeric($codcurso) && is_string($nomecurso) && $nomecurso != "") {
    $tiposie = array();
    $cont = 0;
    $daotpi = new TipoprodintelectualDAO();
    $daopi = new ProdintelectualDAO();
    $validade=2014;
     
    if ($anobase<=2013){
    	$validade=2013;
    }
    $rows_tpi = $daotpi->Lista($validade);
    foreach ($rows_tpi as $row) {
    	$tipospi[$cont] = new Tipoprodintelectual();
        $tipospi[$cont]->setCodigo($row['Codigo']);
        $tipospi[$cont]->setNome($row['Nome']);
        $cont++;
    }
    $cont1 = 0;
    $curso = new Curso();
    $curso->setCodcurso($codcurso);
    $curso->setNomecurso($nomecurso);
    $soma = 0;
    $tamanho = count($tipospi);
    echo $codcurso.",".$anobase.".".$validade;
    if ($validade<=2013){
       $rows_pi = $daopi->tiponaoinserido($codcurso, $anobase,$validade);
     }
    
    if (($rows_pi->rowCount() == 0) || ($validade>2013)){
        $rows_pi = $daopi->buscapiunidade($codcurso, $anobase);
    }
    foreach ($rows_pi as $row) {
    	 
        $tipo = $row['Tipo'];
        for ($i = 0; $i < $tamanho; $i++) {
            if ($tipospi[$i]->getCodigo() == $tipo) {
                $tipospi[$i]->criaProdintelectual($row["Codigo"], $curso, $anobase, $row["Quantidade"]);
                $soma +=$row["Quantidade"];
                $cont1++;
            }
        }
    }
}
$daotpi->fechar();
if ($cont1 == 0) {
   Utils::redirect('prodintelectual', 'incluiprodintelectual', array('codcurso' => $codcurso, 'nomecurso' => $nomecurso));
}
?>
<script language="javascript">
    function direciona(botao) {
        switch (botao) {
            case 1:
                document.getElementById('pi').action = "?modulo=prodintelectual&acao=altprodintelectual";
                document.getElementById('pi').submit();
                break;
            case 2:
                document.getElementById('pi').action = "?modulo=prodintelectual&acao=consultaitempi";
                document.getElementById('pi').submit();
                break;
        }
    }
</script>


<form name="pi" id="pi" method="POST">
    <h3>Produção Intelectual</h3> Curso:
    <?php echo $nomecurso; ?>
    <div class="msg" id="msg"></div>
    <br />

    <table class="tablesorter-dropbox">
        <tfoot>
            <tr>
                <th colspan="7" class="ts-pager form-horizontal">
                    <button type="button" class="btn first"><i class="icon-step-backward glyphicon glyphicon-step-backward"></i></button>
                    <button type="button" class="btn prev"><i class="icon-arrow-left glyphicon glyphicon-backward"></i></button>
                    <span class="pagedisplay"></span> <!-- this can be any element, including an input -->
                    <button type="button" class="btn next"><i class="icon-arrow-right glyphicon glyphicon-forward"></i></button>
                    <button type="button" class="btn last"><i class="icon-step-forward glyphicon glyphicon-step-forward"></i></button>
                    <select class="pagesize input-mini" title="Select page size">
                        <option selected="selected" value="10">10</option>
                        <option value="20">20</option>
                        <option value="30">30</option>
                        <option value="40">40</option>
                    </select>
                    <select class="pagenum input-mini" title="Select page number"></select>
                </th>
            </tr>
        </tfoot>
        <thead>
            <tr align="center" style="font-style: italic;">
                <th>Itens</th>
                <th>Quantidade</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tipospi as $t) { ?>
                <tr>
                    <td><?php print ($t->getNome()); ?></td>
                    <td><?php print $t->getProdintelectual()->getQuantidade(); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <div>
        <p>Total Geral: <b><?php print $soma; ?></b></p>
    </div>
    <input type="hidden" name="codcurso" value="<?php print $codcurso ?>" />
    <input type="hidden" name="nomecurso" value="<?php print $nomecurso ?>" />
    <input name="operacao" type="hidden" value="A" />
    <input type="button" onclick="direciona(1);" value="Alterar" />
    <input type="button" onclick="direciona(2);" value="Incluir novo item" />
</form>

