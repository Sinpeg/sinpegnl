<?php
class Iniciativa {
	
	private $codIniciativa;
	private $nome;
	private $unidade;
	private $finalidade;
	private $coordenador;
	
	// 	public function __construct($codigo, $documento, $perspectiva, $objetivoPDI, $calendario, $propMapa, $dataCdastro, $visao) {
	
	// 		$this->codigo = $codigo;
	// 		$this->documento = $documento;
	// 		$this->perspectiva = $perspectiva;
	// 		$this->objetivoPDI = $objetivoPDI;
	// 		$this->calendario = $calendario;
	// 		$this->propMapa = $propMapa;
	// 		$this->dataCadastro = $dataCdastro;
	// 		$this->visao = $visao;
	
	// 	}
	
	public function setCodIniciativa($codIniciativa) {
		$this->codIniciativa = $codIniciativa;
	}
	
	public function getCodIniciativa() {
		return $this->codIniciativa;
	}
	
	public function setNome($nome) {
		$this->nome = $nome;
	}
	
	public function getNome() {
		return $this->nome;
	}
	
	public function setUnidade(Unidade $unidade) {
		$this->unidade = $unidade;
	}
	
	public function getUnidade() {
		return $this->unidade;
	}	
	public function setFinalidade($finalidade){
		$this->finalidade = $finalidade;
	}
	
	public function getFinalidade(){
		return $this->finalidade;
	}
	
	public function setCoordenador($coordenador) {
		$this->coordenador = $coordenador;
	}
	
	public function getCoordenador() {
		return $this->coordenador;
	}
	
}

?>