<?php
class IndicIniciativa {
	
	private $codigo;
	private $mapaindicador;
	private $iniciativa;
	
	
	public function setMapaindicador($mapaindicador) {
		$this->mapaindicador = $mapaindicador;
	}
	
	public function getMapaindicador() {
		return $this->mapaindicador;
	}
    
    public function setIniciativa($iniciativa) {
		$this->iniciativa = $iniciativa;
	}
	
	public function getIniciativa() {
		return $this->iniciativa;
	}
}
?>