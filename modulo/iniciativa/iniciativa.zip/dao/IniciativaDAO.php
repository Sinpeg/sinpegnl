<?php

class IniciativaDAO extends PDOConnectionFactory {
	
	public $conex = null;
	/*
	 public function MapaDAO() {
	 $this->conex = PDOConnectionFactory::getConnection();
	 }
	 */
	public function insere(Iniciativa $iniciativa) {
		try {
			$sql = "INSERT INTO `iniciativa` (`nome`, `codUnidade`, `finalidade`, `coordenador`)
					VALUES (?,?,?,?)";
			$stmt = parent::prepare($sql);
			parent::beginTransaction();
			$stmt->bindValue(1, $iniciativa->getNome());
			$stmt->bindValue(2, $iniciativa->getUnidade()->getCodunidade());
			$stmt->bindValue(3, $iniciativa->getFinalidade());
			$stmt->bindValue(4, $iniciativa->getCoordenador());
			$stmt->execute();
			parent::commit();
		} catch (PDOException $ex) {
			parent::rollback();
			print "Erro: Código:" . $ex->getCode() . "Mensagem" . $ex->getMessage();
		}
	}
	
// 	public function buscaMpaByCodigoIndicador($codindicador){
// 		try {
// 			$sql = "SELECT * FROM `mapa` m JOIN `mapaindicador` maI ON(m.Codigo = maI.codMapa) WHERE maI.codIndicador = :codind"  ;
// 			$stmt = parent::prepare($sql);
// 			$stmt->execute(array(':codind' => $codindicador));
// 			return $stmt;
// 		} catch (PDOException $ex) {
// 			echo "Erro: " . $ex->getMessage();
// 		}
// 	}
	
	public function altera(Iniciativa $iniciativa) {
		try {
			$sql = "UPDATE `iniciativa` SET `nome` =?, `codIndicador` =?, `codUnidade` =?,
					  `finalidade` =?, `coordenador` =? WHERE `codIniciativa`=?";
			$stmt = parent::prepare($sql);
			parent::beginTransaction();
			//            print $sql;
			$stmt->bindValue(1, $iniciativa->getNome());
			$stmt->bindValue(2, $iniciativa->getUnidade()->getCodunidade());
			$stmt->bindValue(3, $iniciativa->getFinalidade());
			$stmt->bindValue(4, $iniciativa->getCoordenador());
			$stmt->bindValue(5, $iniciativa->getCodIniciativa());
			
			$stmt->execute();
			parent::commit();
		} catch (PDOException $ex) {
			print "Erro: " . $ex->getCode() . " " . $ex->getMessage();
		}
	}
	
	public function deleta($codInciativa) {
		try {
			
			parent::beginTransaction();
			$stmt = parent::prepare("DELETE FROM `iniciativa` WHERE `codInicativa`=?");
			$stmt->bindValue(1, $codInciativa);
			$stmt->execute();
			parent::commit();
		} catch (PDOException $ex) {
			parent::rollback();
			print "Erro: Código:" . $ex->getCode() . "Mensagem" . $ex->getMessage();
		}
	}
	
	public function lista() {
		try {
			$stmt = parent::query("SELECT * FROM `iniciativa` ORDER BY `codIniciativa`");
			return $stmt;
		} catch (PDOException $ex) {
			echo "Erro: " . $ex->getMessage();
		}
	}
	
	
	public function fechar() {
		PDOConnectionFactory::Close();
	}
	
	
}

?>