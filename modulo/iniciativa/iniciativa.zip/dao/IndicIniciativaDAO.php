<?php
class IndicIniciativaDAO extends PDOConnectionFactory {
	
	public $conex = null;
    
    
    public function iniciativaPorMapIndicador($micodigo) {
        $sql=" SELECT i.`codIniciativa` , i.`nome` , i.`finalidade`
FROM  `iniciativa` i
INNER JOIN  `indic_iniciativa` ii ON i.`codIniciativa` = ii.`codIniciativa` 
INNER JOIN  `mapaindicador` mi ON mi.`codigo` = ii.`codMapaInd` 
WHERE mi.`codigo` =:micodigo";
		try {
            $stmt = parent::prepare($sql);
    		$stmt->execute(array(':micodigo' => $micodigo));
			return $stmt;
		} catch (PDOException $ex) {
			echo "Erro iniciativaPorMapIndicador: " . $ex->getMessage();
		}
	}
}

?>